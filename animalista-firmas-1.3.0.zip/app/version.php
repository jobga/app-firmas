<?php
/**
 * Animalista · Plataforma de firmas
 * Autor: Jonnathan Bucheli Galindo
 * © Jonnathan Bucheli Galindo. Todos los derechos reservados.
 */
const APP_NAME = 'Animalista · Plataforma de firmas';
const APP_VERSION = '1.3.0';
/** Versión del esquema de base de datos. Súbela al agregar una migración en app/migrations.php. */
const DB_VERSION = 4;
const APP_AUTHOR = 'Jonnathan Bucheli Galindo';
const APP_MIN_PHP = '8.1.0';
